# Zabee Info Tech Solutions - Employee Management System

A Spring Boot application where I implemented a complete CRUD (Create, Read, Update, Delete) system for employee management using Excel file storage.

## Features

- **Complete CRUD Operations**: Create, Read, Update, and Delete employees
- **Excel File Storage**: Data persistence using Apache POI
- **RESTful API**: Full implementation of HTTP methods
- **Modern Web Interface**: Responsive design with real-time updates
- **Data Validation**: Duplicate ID checks and input validation

## Technology Stack

- **Backend**: Java 17, Spring Boot 3.3.1
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Data Storage**: Apache POI (Excel files)
- **Build Tool**: Maven

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/employees` | Retrieve all employees |
| GET | `/api/employees/{id}` | Retrieve employee by ID |
| POST | `/api/employees` | Create new employee |
| PUT | `/api/employees/{id}` | Update existing employee |
| DELETE | `/api/employees/{id}` | Delete employee by ID |

## How to Run

1. **Prerequisites**: Java 17, Maven
2. **Clone the repository**
3. **Run the application**:
   ```bash
   mvn spring-boot:run
   ```
4. **Access the application**: `http://localhost:8080`


## 🎯 Assessment Questions

### 1. How easy was the implementation of the API into your program?

The implementation was moderately challenging. Key aspects:

**Easy Parts:**
- RESTful annotations (`@GetMapping`, `@PostMapping`, etc) are intuitive
- Dependency injection simplified component management

**Challenging Parts:**
- Excel file operations with Apache POI required careful handling
- Thread safety for concurrent file access needed synchronization
- Frontend backend integration requires proper error handling
- Parameter binding issues with Spring Boot needs troubleshooting

**Learning Outcome:** The process taught me the importance of proper exception handling, thread safety, and the value of Spring Boot's conventions.

### 2. What did you learn from trying to use the 4 methods to manipulate the program?

**GET Method:**
- Learned to handle both single resource retrieval and collection retrieval
- Understood the importance of data serialization/deserialization

**POST Method:**
- Implemented data validation -duplicate ID checks
- Learned to handle request body parsing and validation

**PUT Method:**
- Implemented idempotent operations - same request = same result
- Handled updates and data transformation

**DELETE Method:**
- Implemented proper resource removal with confirmation
- Learned to handle cascading effects (row shifting in Excel)

**Overall Learnings:**
- HTTP method semantics and when to use each
- Proper error handling
- Data consistency and validation
- Frontend-backend communication patterns

### 3. Why did you choose this API?

I chose to create an **Employee Management System** for the following reasons:

**Practical Relevance:**
- Employee data management is a common real-world requirement
- Demonstrates typical business application patterns
- Shows how to handle structured data with relationships

**Technical Learning:**
- Excel file storage demonstrates file I/O operations
- CRUD operations covers all fundamental data manipulation patterns
- Provides opportunity to implement proper data validation

**Educational Value:**
- Covers all four HTTP methods comprehensively
- Demonstrated both backend API and frontend integration
- Shows real-world considerations like data persistence and user interface


## 🔧 Technical Implementation Details

### Backend Architecture
- **Controller Layer**: Handles HTTP requests and responses
- **Repository Layer**: Manages Excel file operations
- **Model Layer**: Employee entity with proper encapsulation
- **Exception Handling**: Global exception handlers for proper error responses

### Frontend Features
- **Responsive Design**: Works on desktop and mobile devices
- **Real-time Updates**: Table refreshes after operations
- **Modal Dialogs**: Clean user interface for editing
- **Form Validation**: Client-side and server-side validation

### Data Storage
- **Excel File**: `employees.xlsx` with proper headers
- **Thread Safety**: Synchronized operations for concurrent access
- **Data Integrity**: Proper error handling and validation