package com.zabee.excelcrud;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Repository;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Repository
public class ExcelRepository {
    private final Path filePath = Path.of("employees.xlsx");
    private final String SHEET = "Employees";
    public ExcelRepository() throws IOException {
        if (!Files.exists(filePath)) {
            try (Workbook wb = new XSSFWorkbook()) {
                Sheet s = wb.createSheet(SHEET);
                Row header = s.createRow(0);
                String[] headers = {"EmployeeId", "Name", "Age", "Location", "Designation", "Branch", "Salary", "Level"};
                for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);
                Object[][] rows = {
                        {1001, "Abhi", 23, "Hyderabad", "Associate Software Engineer", "Development", 35000.0, 3},
                        {2001, "Priya", 22, "Hyderabad", "Human Resource", "Talent Hunting", 22000.0, 2}
                };
                for (int r = 0; r < rows.length; r++) {
                    Row row = s.createRow(r + 1);
                    for (int c = 0; c < rows[r].length; c++) {
                        if (rows[r][c] instanceof Number) {
                            row.createCell(c).setCellValue(((Number) rows[r][c]).doubleValue());
                        } else {
                            row.createCell(c).setCellValue(rows[r][c].toString());
                        }
                    }
                }
                try (OutputStream os = Files.newOutputStream(filePath)) {
                    wb.write(os);
                }
            }
        }
    }

    private synchronized Workbook openWorkbook() throws IOException {
        try (InputStream is = Files.newInputStream(filePath)) {
            return new XSSFWorkbook(is);
        }
    }

    public synchronized List<Employee> findAll() throws IOException {
        List<Employee> list = new ArrayList<>();
        try (Workbook wb = openWorkbook()) {
            Sheet s = wb.getSheet(SHEET);
            if (s == null) return list;
            Iterator<Row> it = s.rowIterator();
            if (it.hasNext()) it.next();
            while (it.hasNext()) {
                Row r = it.next();
                if (r == null) continue;
                Employee e = new Employee(
                        (int) r.getCell(0).getNumericCellValue(),
                        r.getCell(1).getStringCellValue(),
                        (int) r.getCell(2).getNumericCellValue(),
                        r.getCell(3).getStringCellValue(),
                        r.getCell(4).getStringCellValue(),
                        r.getCell(5).getStringCellValue(),
                        r.getCell(6).getNumericCellValue(),
                        (int) r.getCell(7).getNumericCellValue()
                );
                list.add(e);
            }
        }
        return list;
    }

    public synchronized Optional<Employee> findById(int id) throws IOException {
        return findAll().stream().filter(e -> e.getEmployeeId() == id).findFirst();
    }

    public synchronized void save(Employee emp) throws IOException {
        try (Workbook wb = openWorkbook()) {
            Sheet s = wb.getSheet(SHEET);
            int lastRow = s.getLastRowNum();
            Row row = s.createRow(lastRow + 1);
            writeRow(emp, row);
            try (OutputStream os = Files.newOutputStream(filePath)) {
                wb.write(os);
            }
        }
    }

    public synchronized boolean update(int id, Employee data) throws IOException {
        try (Workbook wb = openWorkbook()) {
            Sheet s = wb.getSheet(SHEET);
            for (int i = 1; i <= s.getLastRowNum(); i++) {
                Row r = s.getRow(i);
                if (r == null || r.getCell(0) == null) continue;
                int rid = (int) r.getCell(0).getNumericCellValue();
                if (rid == id) {
                    writeRow(data, r);
                    try (OutputStream os = Files.newOutputStream(filePath)) {
                        wb.write(os);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public synchronized boolean delete(int id) throws IOException {
        try (Workbook wb = openWorkbook()) {
            Sheet s = wb.getSheet(SHEET);
            if (s == null) return false;
            
            for (int i = 1; i <= s.getLastRowNum(); i++) {
                Row r = s.getRow(i);
                if (r == null || r.getCell(0) == null) continue;
                
                try {
                    int rid = (int) r.getCell(0).getNumericCellValue();
                    if (rid == id) {
                        int last = s.getLastRowNum();
                        if (i < last) {
                            s.shiftRows(i + 1, last, -1);
                        } else {
                            s.removeRow(r);
                        }
                        
                        try (OutputStream os = Files.newOutputStream(filePath)) {
                            wb.write(os);
                        }
                        return true;
                    }
                } catch (Exception e) {
                    continue;
                }
            }
        }
        return false;
    }

    private void writeRow(Employee e, Row row) {
        row.createCell(0).setCellValue(e.getEmployeeId());
        row.createCell(1).setCellValue(e.getName());
        row.createCell(2).setCellValue(e.getAge());
        row.createCell(3).setCellValue(e.getLocation());
        row.createCell(4).setCellValue(e.getDesignation());
        row.createCell(5).setCellValue(e.getBranch());
        row.createCell(6).setCellValue(e.getSalary());
        row.createCell(7).setCellValue(e.getLevel());
    }
}
