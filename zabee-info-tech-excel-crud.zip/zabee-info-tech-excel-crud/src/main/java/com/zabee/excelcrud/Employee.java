package com.zabee.excelcrud;
public class Employee {
    private int employeeId;
    private String name;
    private int age;
    private String location;
    private String designation;
    private String branch;
    private double salary;
    private int level;
    public Employee() {}
    public Employee(int employeeId, String name, int age, String location, String designation, String branch, double salary, int level) {
        this.employeeId = employeeId;
        this.name = name;
        this.age = age;
        this.location = location;
        this.designation = designation;
        this.branch = branch;
        this.salary = salary;
        this.level = level;
    }
    
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    public String getBranch() { return branch; }
    public void setBranch(String branch) { this.branch = branch; }
    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
}
