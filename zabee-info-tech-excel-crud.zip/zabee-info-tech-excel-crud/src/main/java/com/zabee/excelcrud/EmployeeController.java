package com.zabee.excelcrud;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final ExcelRepository repo;
    public EmployeeController(ExcelRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Employee> all() throws IOException {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> findById(@PathVariable("id") String idStr) throws IOException {
        try {
            int id = Integer.parseInt(idStr);
            Optional<Employee> employee = repo.findById(id);
            return employee.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Employee e) throws IOException {
        if (repo.findById(e.getEmployeeId()).isPresent()) {
            return ResponseEntity.status(409).body("Employee with this ID already exists");
        }
        repo.save(e);
        return ResponseEntity.ok(e);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable("id") String idStr, @RequestBody Employee e) throws IOException {
        try {
            int id = Integer.parseInt(idStr);
            if (id != e.getEmployeeId()) {
                return ResponseEntity.badRequest().body("Path ID and body employeeId must match");
            }
            boolean ok = repo.update(id, e);
            return ok ? ResponseEntity.ok(e) : ResponseEntity.notFound().build();
        } catch (NumberFormatException ex) {
            return ResponseEntity.badRequest().body("Invalid employee ID format");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") String idStr) throws IOException {
        try {
            int id = Integer.parseInt(idStr);
            boolean ok = repo.delete(id);
            return ok ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("Invalid employee ID format");
        }
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<String> handleIOException(IOException e) {
        System.err.println("IOException occurred: " + e.getMessage());
        e.printStackTrace();
        return ResponseEntity.status(500).body("Internal server error: " + e.getMessage());
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception e) {
        System.err.println("Exception occurred: " + e.getMessage());
        e.printStackTrace();
        return ResponseEntity.status(500).body("Internal server error: " + e.getMessage());
    }
}
